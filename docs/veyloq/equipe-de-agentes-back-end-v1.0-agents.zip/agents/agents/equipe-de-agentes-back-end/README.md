# Back-end team

A team of Claude Code subagents. Each file is one agent; ask for the coordinator role in plain language and it delegates to the others.

- **backend-developer**: services and business rules
- **api-designer**: API contracts
- **postgres-pro**: schema and queries
- **devops-engineer**: build and deploy

Original agents: VoltAgent/awesome-claude-code-subagents (MIT).

<!-- veyloq-credit -->
> Original: Awesome Claude Code Subagents, by VoltAgent (MIT). https://github.com/VoltAgent/awesome-claude-code-subagents @ ed74d11
