# Créditos e licenças

Itens deste arquivo criados por outras pessoas e publicados na VEYLOQ com a licença delas. Mantenha este arquivo junto se você compartilhar os itens.

## Arquiteto de back-end: serviço, API e eventos desenhados

wshobson/agents: agente backend-development-backend-architect, de Seth Hobson (wshobson). Licença MIT. Original: https://github.com/wshobson/agents (commit 7e2fb559cf4b824b27f1fec49fe88f7511066d26).

Caminho no original: `plugins/backend-development/agents/backend-architect.md`

O que a VEYLOQ mudou: Linha de crédito acrescentada no fim do arquivo.

### Texto da licença original

```text
MIT License

Copyright (c) 2024 Seth Hobson

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```
