# Créditos e licenças

Itens deste arquivo criados por outras pessoas e publicados na VEYLOQ com a licença delas. Mantenha este arquivo junto se você compartilhar os itens.

## Equipe de agentes de dados: consulta, pipeline e modelo

Awesome Claude Code Subagents, de VoltAgent. Licença MIT. Original: https://github.com/VoltAgent/awesome-claude-code-subagents (commit ed74d115b7fb7026a22a4f816a8e3250f425e3b4).

Caminho no original: `categories/`

O que a VEYLOQ mudou: Agentes reunidos em equipe pela VoltAgent original, com um README de papéis escrito pela VEYLOQ.

### Texto da licença original

```text
MIT License

Copyright (c) 2025 VoltAgent

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```
