# Data team

A team of Claude Code subagents. Each file is one agent; ask for the coordinator role in plain language and it delegates to the others.

- **data-analyst**: questions and dashboards
- **data-engineer**: pipelines
- **data-scientist**: models
- **sql-pro**: queries

Original agents: VoltAgent/awesome-claude-code-subagents (MIT).

<!-- veyloq-credit -->
> Original: Awesome Claude Code Subagents, by VoltAgent (MIT). https://github.com/VoltAgent/awesome-claude-code-subagents @ ed74d11
