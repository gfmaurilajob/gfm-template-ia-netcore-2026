# Superpowers: o fluxo de entrega, do plano ao merge · versão 1.0

Arquivo da VEYLOQ pra Outras ferramentas, versão 1.0 de 05/11/2026. O item fica na sua biblioteca, sempre na versão mais nova.

## Como instalar

1. Abra o arquivo e copie o conteúdo da pasta agents pra raiz do seu projeto.
2. Se o projeto já tem um AGENTS.md, junte o texto do arquivo novo ao seu.
3. A ferramenta passa a usar o item na próxima conversa.

## O que tem dentro

- `agents/.agents/skills/executing-plans/LICENSE.txt`
- `agents/.agents/skills/executing-plans/SKILL.md`
- `agents/.agents/skills/executing-plans/scripts/task-done`
- `agents/.agents/skills/executing-plans/scripts/task-start`
- `agents/.agents/skills/finishing-a-development-branch/LICENSE.txt`
- `agents/.agents/skills/finishing-a-development-branch/SKILL.md`
- `agents/.agents/skills/receiving-code-review/LICENSE.txt`
- `agents/.agents/skills/receiving-code-review/SKILL.md`
- `agents/.agents/skills/requesting-code-review/LICENSE.txt`
- `agents/.agents/skills/requesting-code-review/SKILL.md`
- `agents/.agents/skills/requesting-code-review/code-reviewer.md`
- `agents/.agents/skills/subagent-driven-development/LICENSE.txt`
- `agents/.agents/skills/subagent-driven-development/SKILL.md`
- `agents/.agents/skills/subagent-driven-development/implementer-prompt.md`
- `agents/.agents/skills/subagent-driven-development/re-review-prompt.md`
- `agents/.agents/skills/subagent-driven-development/references/batching.md`
- `agents/.agents/skills/subagent-driven-development/references/cannot-verify.md`
- `agents/.agents/skills/subagent-driven-development/references/final-review.md`
- `agents/.agents/skills/subagent-driven-development/references/fix-loop.md`
- `agents/.agents/skills/subagent-driven-development/references/handling-reports.md`
- `agents/.agents/skills/subagent-driven-development/references/preflight.md`
- `agents/.agents/skills/subagent-driven-development/references/resuming.md`
- `agents/.agents/skills/subagent-driven-development/scripts/review-package`
- `agents/.agents/skills/subagent-driven-development/scripts/sdd-repo`
- `agents/.agents/skills/subagent-driven-development/scripts/sdd-workspace`
- `agents/.agents/skills/subagent-driven-development/scripts/task-brief`
- `agents/.agents/skills/subagent-driven-development/task-reviewer-prompt.md`
- `agents/.agents/skills/using-git-worktrees/LICENSE.txt`
- `agents/.agents/skills/using-git-worktrees/SKILL.md`
- `agents/.agents/skills/verification-before-completion/LICENSE.txt`
- `agents/.agents/skills/verification-before-completion/SKILL.md`
- `agents/ATTRIBUTION.md`
- `agents/kits/superpowers-fluxo-de-entrega/superpowers-fluxo-de-entrega.md`

O uso segue a licença do arquivo LICENSE.txt e os termos de uso da VEYLOQ.
