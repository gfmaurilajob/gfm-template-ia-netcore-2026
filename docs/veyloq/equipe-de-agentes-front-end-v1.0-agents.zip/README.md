# Equipe de agentes de front-end: da tela ao teste · versão 1.0

Arquivo da VEYLOQ pra Outras ferramentas, versão 1.0 de 05/11/2026. O item fica na sua biblioteca, sempre na versão mais nova.

## Como instalar

1. Abra o arquivo e copie o conteúdo da pasta agents pra raiz do seu projeto.
2. Se o projeto já tem um AGENTS.md, junte o texto do arquivo novo ao seu.
3. A ferramenta passa a usar o item na próxima conversa.

## O que tem dentro

- `agents/AGENTS.md`
- `agents/ATTRIBUTION.md`
- `agents/agents/equipe-de-agentes-front-end/LICENSE.txt`
- `agents/agents/equipe-de-agentes-front-end/README.md`

O uso segue a licença do arquivo LICENSE.txt e os termos de uso da VEYLOQ.
