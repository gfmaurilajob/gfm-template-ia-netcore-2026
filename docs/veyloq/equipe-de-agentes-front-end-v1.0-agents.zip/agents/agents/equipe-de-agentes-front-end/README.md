# Front-end team

A team of Claude Code subagents. Each file is one agent; ask for the coordinator role in plain language and it delegates to the others.

- **nextjs-developer**: pages, routes and data
- **react-specialist**: components and state
- **typescript-pro**: types
- **ui-designer**: layout and visual consistency
- **accessibility-tester**: WCAG checks

Original agents: VoltAgent/awesome-claude-code-subagents (MIT).

<!-- veyloq-credit -->
> Original: Awesome Claude Code Subagents, by VoltAgent (MIT). https://github.com/VoltAgent/awesome-claude-code-subagents @ ed74d11
