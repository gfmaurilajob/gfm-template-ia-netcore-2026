# UI UX Pro Max: design system pronto para o seu produto · versão 1.0

Arquivo da VEYLOQ pra Outras ferramentas, versão 1.0 de 05/11/2026. O item fica na sua biblioteca, sempre na versão mais nova.

## Como instalar

1. Abra o arquivo e copie o conteúdo da pasta agents pra raiz do seu projeto.
2. Se o projeto já tem um AGENTS.md, junte o texto do arquivo novo ao seu.
3. A ferramenta passa a usar o item na próxima conversa.

## O que tem dentro

- `agents/.agents/skills/ui-ux-pro-max-design/SKILL.md`
- `agents/ATTRIBUTION.md`

O uso segue a licença do arquivo LICENSE.txt e os termos de uso da VEYLOQ.
