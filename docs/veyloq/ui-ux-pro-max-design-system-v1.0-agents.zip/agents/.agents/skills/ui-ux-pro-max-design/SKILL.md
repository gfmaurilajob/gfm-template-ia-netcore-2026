---
name: ui-ux-pro-max-design
description: Use when the user wants a design system or UI direction (style, palette, font pairing, layout, UX rules) for a web or mobile interface, using the open-source UI UX Pro Max skill and its searchable database of styles, colors, typography, charts and stack-specific guidelines.
---

# Design systems with UI UX Pro Max

UI UX Pro Max (by Next Level Builder, open source, MIT) is a design intelligence skill for coding agents. It ships a local, searchable database of UI styles, color palettes by product type, font pairings, chart types, landing page patterns, UX guidelines and stack notes (React, Next.js, Vue, Svelte, Flutter, SwiftUI, React Native, Tailwind, shadcn and more), plus a reasoning step that turns a product brief into a complete design system. This guide tells the AI when to use it and how to install it from the official source.

## Setup (once per project)

1. Requirements: Node.js for the installer and Python 3 for the search scripts the skill runs locally.
2. Install from the official package:

   ```
   npm install -g ui-ux-pro-max-cli
   uipro init --ai claude      # or cursor, codex, copilot, antigravity, gemini, universal
   ```

   In Claude Code you can also run `/plugin marketplace add nextlevelbuilder/ui-ux-pro-max-skill` and `/plugin install ui-ux-pro-max@ui-ux-pro-max-skill`. Use the `ui-ux-pro-max-cli` package; the older `uipro-cli` releases are stale.
3. Update later with `uipro update`.

Official source: https://github.com/nextlevelbuilder/ui-ux-pro-max-skill. Install only from there or from its documented commands.

## How to work with it

1. Start from the brief: what the product is, who uses it, the platform and the stack.
2. Ask the skill for a design system first (style, palette, typography, spacing, effects, anti-patterns), then build the screens on top of it.
3. Keep the result as tokens (CSS variables or Tailwind theme) so every screen reuses the same decisions.
4. Check the UX rules it returns before delivery: contrast, touch targets, focus states, loading and empty states.
5. If the project already has a brand or a design system, use the skill to fill gaps, not to replace what exists.

## Typical requests

- "Build a design system for a fintech dashboard in Next.js and Tailwind."
- "Which font pairing and palette fit a meditation app?"
- "Review this landing page against the UX guidelines and list what breaks."
- "Generate the tokens for a SaaS admin and apply them to these components."

<!-- veyloq-credit -->
> Guide written by VEYLOQ about: UI UX Pro Max, by Next Level Builder (MIT). https://github.com/nextlevelbuilder/ui-ux-pro-max-skill @ ccce51c

## Response language

Always answer the user in Brazilian Portuguese (pt-BR), even though these instructions are in English. Keep code, commands, file names and technical terms as they are.
