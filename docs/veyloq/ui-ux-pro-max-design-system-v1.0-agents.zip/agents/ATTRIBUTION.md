# Créditos e licenças

Itens deste arquivo criados por outras pessoas e publicados na VEYLOQ com a licença delas. Mantenha este arquivo junto se você compartilhar os itens.

## UI UX Pro Max: design system pronto para o seu produto

UI UX Pro Max, de Next Level Builder. Licença MIT. Original: https://github.com/nextlevelbuilder/ui-ux-pro-max-skill (commit ccce51cba388476d4f403091ddb91636d5cd9fed).

Este item é um guia da VEYLOQ que ensina a usar o projeto original. O projeto fica no endereço acima, com a licença dele.
