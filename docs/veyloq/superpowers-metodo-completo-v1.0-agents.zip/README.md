# Superpowers: o método completo de programar com IA · versão 1.0

Arquivo da VEYLOQ pra Outras ferramentas, versão 1.0 de 05/11/2026. O item fica na sua biblioteca, sempre na versão mais nova.

## Como instalar

1. Abra o arquivo e copie o conteúdo da pasta agents pra raiz do seu projeto.
2. Se o projeto já tem um AGENTS.md, junte o texto do arquivo novo ao seu.
3. A ferramenta passa a usar o item na próxima conversa.

## O que tem dentro

- `agents/.agents/skills/brainstorming/LICENSE.txt`
- `agents/.agents/skills/brainstorming/SKILL.md`
- `agents/.agents/skills/brainstorming/builder-check-prompt.md`
- `agents/.agents/skills/brainstorming/scripts/frame-template.html`
- `agents/.agents/skills/brainstorming/scripts/helper.js`
- `agents/.agents/skills/brainstorming/scripts/server.cjs`
- `agents/.agents/skills/brainstorming/scripts/start-server.sh`
- `agents/.agents/skills/brainstorming/scripts/stop-server.sh`
- `agents/.agents/skills/brainstorming/visual-companion.md`
- `agents/.agents/skills/systematic-debugging/LICENSE.txt`
- `agents/.agents/skills/systematic-debugging/SKILL.md`
- `agents/.agents/skills/systematic-debugging/condition-based-waiting-example.ts`
- `agents/.agents/skills/systematic-debugging/condition-based-waiting.md`
- `agents/.agents/skills/systematic-debugging/defense-in-depth.md`
- `agents/.agents/skills/systematic-debugging/find-polluter.sh`
- `agents/.agents/skills/systematic-debugging/root-cause-tracing.md`
- `agents/.agents/skills/test-driven-development/LICENSE.txt`
- `agents/.agents/skills/test-driven-development/SKILL.md`
- `agents/.agents/skills/test-driven-development/writing-good-tests.md`
- `agents/.agents/skills/writing-plans/LICENSE.txt`
- `agents/.agents/skills/writing-plans/SKILL.md`
- `agents/ATTRIBUTION.md`
- `agents/kits/superpowers-metodo-completo/superpowers-metodo-completo.md`

O uso segue a licença do arquivo LICENSE.txt e os termos de uso da VEYLOQ.
