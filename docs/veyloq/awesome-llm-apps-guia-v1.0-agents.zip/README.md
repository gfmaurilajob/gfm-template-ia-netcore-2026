# Awesome LLM Apps: guia para rodar um app de IA pronto · versão 1.0

Arquivo da VEYLOQ pra Outras ferramentas, versão 1.0 de 05/11/2026. O item fica na sua biblioteca, sempre na versão mais nova.

## Como instalar

1. Abra o arquivo e copie o conteúdo da pasta agents pra raiz do seu projeto.
2. Se o projeto já tem um AGENTS.md, junte o texto do arquivo novo ao seu.
3. A ferramenta passa a usar o item na próxima conversa.

## O que tem dentro

- `agents/ATTRIBUTION.md`
- `agents/guides/awesome-llm-apps-guia/awesome-llm-apps-guia.md`

O uso segue a licença do arquivo LICENSE.txt e os termos de uso da VEYLOQ.
