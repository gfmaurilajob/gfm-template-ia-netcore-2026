# Créditos e licenças

Itens deste arquivo criados por outras pessoas e publicados na VEYLOQ com a licença delas. Mantenha este arquivo junto se você compartilhar os itens.

## Awesome LLM Apps: guia para rodar um app de IA pronto

Awesome LLM Apps, de Shubham Saboo. Licença Apache-2.0. Original: https://github.com/Shubhamsaboo/awesome-llm-apps (commit 6c16b23f1bacd0fdf240bb5141ef45e59e82c306).

Este item é um guia da VEYLOQ que ensina a usar o projeto original. O projeto fica no endereço acima, com a licença dele.
