# Awesome LLM Apps: como escolher e rodar um modelo pronto de app com IA

## O que é

O Awesome LLM Apps, de Shubham Saboo, é uma coleção aberta (licença Apache-2.0) com mais de cem projetos prontos de aplicativos com IA: agentes de uma pessoa só, times de agentes, apps de RAG (a IA consultando seus documentos), agentes de voz, apps com memória, servidores MCP e skills para agentes de código. Cada projeto é uma pasta com código, instruções e lista de dependências. Funciona com modelos da OpenAI, Anthropic, Google e modelos abertos.

Repositório oficial: https://github.com/Shubhamsaboo/awesome-llm-apps

Este guia mostra como usar a coleção para aprender e para tirar do papel um protótipo, com segurança.

## Para que serve

- Ver como um tipo de app com IA é montado antes de construir o seu.
- Ter um ponto de partida que já funciona, em vez de começar do zero.
- Comparar abordagens (um agente só, vários agentes, RAG) para o mesmo problema.

## Como escolher um projeto

1. Defina o problema em uma frase: "responder dúvidas de clientes a partir dos nossos PDFs", "analisar uma planilha em português", "resumir notícias do setor toda manhã".
2. Procure a seção certa no README: agentes iniciais (um arquivo, ótimos para começar), agentes avançados, times de agentes, RAG, apps com memória, "Chat with X", agentes de voz, MCP e skills.
3. Prefira um projeto da seção de agentes iniciais para o primeiro teste: menos peças, mais fácil de entender.
4. Abra o README da pasta escolhida e confira: qual modelo ele usa, quais chaves de API pede e quais bibliotecas instala.

## Como rodar, passo a passo

1. Tenha Python e o Git instalados.
2. Clone o repositório e entre na pasta do projeto, como o README do projeto mostra (por exemplo, `starter_ai_agents/ai_travel_agent`).
3. Crie um ambiente virtual do Python antes de instalar dependências, para não misturar com o resto do computador.
4. Instale as dependências com o comando do README (`pip install -r requirements.txt`).
5. Crie a sua chave de API no site do provedor do modelo e coloque-a do jeito que o README pede (variável de ambiente ou campo na tela do app). Nunca escreva a chave dentro do código que você vai compartilhar.
6. Rode o comando do README (muitos projetos usam `streamlit run <arquivo>.py`) e abra o endereço local que aparecer.

As skills para agentes de código podem ser instaladas com a CLI de skills, por exemplo `npx skills add` seguido do endereço da pasta da skill no repositório.

## Cuidados

- **Leia o código antes de rodar.** São projetos de exemplo. Confira o que cada um faz, que sites acessa e que arquivos lê.
- **Custo.** Cada chamada ao modelo é cobrada pelo provedor. Defina um limite de gasto na conta da API antes de testar agentes que rodam em ciclo.
- **Dados.** Não envie documento sigiloso, dado de cliente ou dado pessoal para um protótipo sem saber para onde ele vai.
- **Áreas sensíveis.** Projetos de saúde, finanças ou jurídico na coleção são demonstrações técnicas. Não use a saída deles como diagnóstico, recomendação de investimento ou parecer.
- **Licença.** A coleção é Apache-2.0: você pode usar e adaptar, mantendo o aviso de licença. Bibliotecas e modelos usados em cada projeto têm licenças e termos próprios.

## Como pedir ajuda à sua IA

Com o projeto aberto na sua ferramenta de IA, peça: "Leia esta pasta do Awesome LLM Apps, explique em português o que o app faz, quais serviços externos ele chama, quanto pode custar por uso e o que eu preciso mudar para usar com os meus dados." Depois peça as mudanças uma de cada vez.

## Fontes

- Repositório: https://github.com/Shubhamsaboo/awesome-llm-apps
- Tutoriais do autor: https://www.theunwindai.com

<!-- veyloq-credit -->
> Guide written by VEYLOQ about: Awesome LLM Apps, by Shubham Saboo (Apache-2.0). https://github.com/Shubhamsaboo/awesome-llm-apps @ 6c16b23
