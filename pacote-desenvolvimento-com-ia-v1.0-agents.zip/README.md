# Pacote desenvolvimento com IA: método, times e qualidade · versão 1.0

Arquivo da VEYLOQ pra Outras ferramentas, versão 1.0 de 05/11/2026. O item fica na sua biblioteca, sempre na versão mais nova.

## Como instalar

1. Abra o arquivo e copie o conteúdo da pasta agents pra raiz do seu projeto.
2. Se o projeto já tem um AGENTS.md, junte o texto do arquivo novo ao seu.
3. A ferramenta passa a usar o item na próxima conversa.

## O que tem dentro

- `agents/.agents/skills/brainstorming/LICENSE.txt`
- `agents/.agents/skills/brainstorming/SKILL.md`
- `agents/.agents/skills/brainstorming/builder-check-prompt.md`
- `agents/.agents/skills/brainstorming/scripts/frame-template.html`
- `agents/.agents/skills/brainstorming/scripts/helper.js`
- `agents/.agents/skills/brainstorming/scripts/server.cjs`
- `agents/.agents/skills/brainstorming/scripts/start-server.sh`
- `agents/.agents/skills/brainstorming/scripts/stop-server.sh`
- `agents/.agents/skills/brainstorming/visual-companion.md`
- `agents/.agents/skills/context-degradation/LICENSE.txt`
- `agents/.agents/skills/context-degradation/SKILL.md`
- `agents/.agents/skills/context-degradation/references/patterns.md`
- `agents/.agents/skills/context-degradation/scripts/degradation_detector.py`
- `agents/.agents/skills/context-fundamentals/LICENSE.txt`
- `agents/.agents/skills/context-fundamentals/SKILL.md`
- `agents/.agents/skills/context-fundamentals/references/context-components.md`
- `agents/.agents/skills/context-fundamentals/scripts/context_manager.py`
- `agents/.agents/skills/context-optimization/LICENSE.txt`
- `agents/.agents/skills/context-optimization/SKILL.md`
- `agents/.agents/skills/context-optimization/references/optimization_techniques.md`
- `agents/.agents/skills/context-optimization/scripts/compaction.py`
- `agents/.agents/skills/executing-plans/LICENSE.txt`
- `agents/.agents/skills/executing-plans/SKILL.md`
- `agents/.agents/skills/executing-plans/scripts/task-done`
- `agents/.agents/skills/executing-plans/scripts/task-start`
- `agents/.agents/skills/finishing-a-development-branch/LICENSE.txt`
- `agents/.agents/skills/finishing-a-development-branch/SKILL.md`
- `agents/.agents/skills/receiving-code-review/LICENSE.txt`
- `agents/.agents/skills/receiving-code-review/SKILL.md`
- `agents/.agents/skills/requesting-code-review/LICENSE.txt`
- `agents/.agents/skills/requesting-code-review/SKILL.md`
- `agents/.agents/skills/requesting-code-review/code-reviewer.md`
- `agents/.agents/skills/subagent-driven-development/LICENSE.txt`
- `agents/.agents/skills/subagent-driven-development/SKILL.md`
- `agents/.agents/skills/subagent-driven-development/implementer-prompt.md`
- `agents/.agents/skills/subagent-driven-development/re-review-prompt.md`
- `agents/.agents/skills/subagent-driven-development/references/batching.md`
- `agents/.agents/skills/subagent-driven-development/references/cannot-verify.md`
- `agents/.agents/skills/subagent-driven-development/references/final-review.md`
- `agents/.agents/skills/subagent-driven-development/references/fix-loop.md`
- `agents/.agents/skills/subagent-driven-development/references/handling-reports.md`
- `agents/.agents/skills/subagent-driven-development/references/preflight.md`
- `agents/.agents/skills/subagent-driven-development/references/resuming.md`
- `agents/.agents/skills/subagent-driven-development/scripts/review-package`
- `agents/.agents/skills/subagent-driven-development/scripts/sdd-repo`
- `agents/.agents/skills/subagent-driven-development/scripts/sdd-workspace`
- `agents/.agents/skills/subagent-driven-development/scripts/task-brief`
- `agents/.agents/skills/subagent-driven-development/task-reviewer-prompt.md`
- `agents/.agents/skills/systematic-debugging/LICENSE.txt`
- `agents/.agents/skills/systematic-debugging/SKILL.md`
- `agents/.agents/skills/systematic-debugging/condition-based-waiting-example.ts`
- `agents/.agents/skills/systematic-debugging/condition-based-waiting.md`
- `agents/.agents/skills/systematic-debugging/defense-in-depth.md`
- `agents/.agents/skills/systematic-debugging/find-polluter.sh`
- `agents/.agents/skills/systematic-debugging/root-cause-tracing.md`
- `agents/.agents/skills/test-driven-development/LICENSE.txt`
- `agents/.agents/skills/test-driven-development/SKILL.md`
- `agents/.agents/skills/test-driven-development/writing-good-tests.md`
- `agents/.agents/skills/using-git-worktrees/LICENSE.txt`
- `agents/.agents/skills/using-git-worktrees/SKILL.md`
- `agents/.agents/skills/verification-before-completion/LICENSE.txt`
- `agents/.agents/skills/verification-before-completion/SKILL.md`
- `agents/.agents/skills/writing-plans/LICENSE.txt`
- `agents/.agents/skills/writing-plans/SKILL.md`
- `agents/AGENTS.md`
- `agents/ATTRIBUTION.md`
- `agents/agents/accessibility-tester/LICENSE.txt`
- `agents/agents/api-designer/LICENSE.txt`
- `agents/agents/backend-developer/LICENSE.txt`
- `agents/agents/debugger/LICENSE.txt`
- `agents/agents/docker-expert/LICENSE.txt`
- `agents/agents/frontend-developer/LICENSE.txt`
- `agents/agents/nextjs-developer/LICENSE.txt`
- `agents/agents/node-specialist/LICENSE.txt`
- `agents/agents/performance-engineer/LICENSE.txt`
- `agents/agents/postgres-pro/LICENSE.txt`
- `agents/agents/python-pro/LICENSE.txt`
- `agents/agents/qa-expert/LICENSE.txt`
- `agents/agents/react-specialist/LICENSE.txt`
- `agents/agents/security-auditor/LICENSE.txt`
- `agents/agents/sql-pro/LICENSE.txt`
- `agents/agents/test-automator/LICENSE.txt`
- `agents/agents/typescript-pro/LICENSE.txt`
- `agents/agents/ui-designer/LICENSE.txt`
- `agents/bundles/pacote-desenvolvimento-com-ia/pacote-desenvolvimento-com-ia.md`
- `agents/commands/component-scaffold/LICENSE.txt`
- `agents/commands/deps-audit/LICENSE.txt`
- `agents/commands/pr-enhance/LICENSE.txt`
- `agents/commands/python-scaffold/LICENSE.txt`
- `agents/commands/security-sast/LICENSE.txt`
- `agents/commands/sql-migrations/LICENSE.txt`
- `agents/commands/test-generate/LICENSE.txt`
- `agents/commands/typescript-scaffold/LICENSE.txt`
- `agents/kits/kit-engenharia-de-contexto-para-agentes/kit-engenharia-de-contexto-para-agentes.md`
- `agents/kits/kit-qualidade-e-seguranca/kit-qualidade-e-seguranca.md`
- `agents/kits/kit-time-de-back-end/kit-time-de-back-end.md`
- `agents/kits/kit-time-de-front-end/kit-time-de-front-end.md`
- `agents/kits/superpowers-fluxo-de-entrega/superpowers-fluxo-de-entrega.md`
- `agents/kits/superpowers-metodo-completo/superpowers-metodo-completo.md`

O uso segue a licença do arquivo LICENSE.txt e os termos de uso da VEYLOQ.
